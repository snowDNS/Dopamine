# StarJail — Dopamine 3.0.13 rebrand

StarJail is a visual rebrand of the Dopamine 3.0.13 source tree. It uses the supplied red demon emblem, a black/crimson default appearance, and the original jailbreak flow and package-manager picker (Sileo/Zebra) from the upstream project.

## Included visual changes
- StarJail app display name and bundle identifier (`com.starjail.app`) in the app target.
- Supplied StarJail artwork in the app header, boot-logo artwork, and app icon sets.
- Black background with a restrained red glow; charcoal action surface and red accent color.
- Default theme renamed StarJail. Other upstream themes remain available.
- Original package-manager selection and jailbreak progress/log implementation retained; no fake completion state is added.

## Build
Open `Application/Dopamine.xcodeproj` in a compatible macOS/Xcode environment and build the StarJail app target/scheme. This archive contains source code; it has not been compiled or device-tested here. The existing upstream deployment settings and exploit support have not been changed. A visual rebrand does not add support for newer iOS versions or create new exploit compatibility.

## Upstream, licensing, and attribution
Based on https://github.com/opa334/Dopamine. Original copyright and license notices are retained. See `LICENSE.md` and component-specific license files. Preserve all notices when redistributing.
